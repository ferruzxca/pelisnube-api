# PelisNube PHP 8.2 Migration

Migracion completa desde Node/Nest a una solucion separada en:

- `php-api/` (`api.tudominio.com`)
- `php-admin/` (`admin.tudominio.com`)

Ambos desacoplados. `php-admin` y la app `.NET MAUI` consumen solo la API por `Bearer JWT`.

## Estructura

- `php-api/public/index.php`: front controller API (`/api/v1`)
- `php-api/database/schema.sql`: esquema completo MySQL
- `php-api/database/seed.sql`: seed con 50 contenidos + planes + usuarios base
- `php-api/scripts/cron-renew-subscriptions.php`: renovacion diaria
- `php-admin/public/index.php`: panel admin HTML/PHP + Bootstrap + Chart.js

## Variables de entorno

### API (`php-api/.env`)

Copia de `php-api/.env.example`.

Valores clave:

- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`
- `JWT_SECRET`, `JWT_TTL_MINUTES`, `JWT_RESET_TTL_MINUTES`
- `APP_CURRENCY` (default `MXN`)
- `DEFAULT_LANG` (`es` / `en`)
- `CORS_ORIGINS` (ej. `https://admin.tudominio.com,https://app.tudominio.com`)

### Admin (`php-admin/.env`)

Copia de `php-admin/.env.example`.

Valores clave:

- `API_BASE_URL=https://api.tudominio.com/api/v1`
- `DEFAULT_LANG=es`

## Instalacion local rapida

1. Importa `php-api/database/schema.sql` en MySQL.
2. Importa `php-api/database/seed.sql`.
3. Copia `.env.example` a `.env` en `php-api` y `php-admin`.
4. Inicia servidores locales:

```bash
php -S localhost:8080 -t php-api/public
php -S localhost:8081 -t php-admin/public
```

5. Abre `http://localhost:8081`.

Credenciales seed:

- `superadmin@pelisnube.local` / `Admin12345!`
- `admin@pelisnube.local` / `Admin12345!`

## Reglas de negocio implementadas

- `signup-with-payment`: pago simulado primero, cuenta despues.
- Simulador de pago:
  - ultimo digito de tarjeta par => `SUCCESS`
  - impar => `FAILED`
- Catalogo:
  - listado publico
  - detalle autenticado
- OTP reset solo para rol `USER`.
- Soft delete / inactivacion en recursos administrativos.
- Auditoria de mutaciones en `audit_logs` + tablas historicas.

## Contrato principal API

Base path: `/api/v1`

Publico:

- `GET /health`
- `GET /catalog`
- `POST /auth/signup-with-payment`
- `POST /auth/login`
- `POST /auth/password/otp/request`
- `POST /auth/password/otp/verify`
- `POST /auth/password/reset`

Auth:

- `GET /catalog/{slug}`
- `GET /sections/home`
- `GET /auth/me`
- Favoritos y suscripcion para `USER`
- Dashboard + CRUD admin para `ADMIN|SUPER_ADMIN`

## Despliegue Hostinger (sin GitHub)

1. Respaldar DB actual desde phpMyAdmin.
2. Crear subdominios:
   - `api.tudominio.com` -> docroot `php-api/public`
   - `admin.tudominio.com` -> docroot `php-admin/public`
3. Subir ZIP del proyecto por File Manager/FTP y extraer.
4. Crear `php-api/.env` y `php-admin/.env`.
5. Importar `php-api/database/schema.sql`.
6. Importar `php-api/database/seed.sql`.
7. Verificar permisos:
   - carpetas `755`
   - archivos `644`
8. Configurar cron diario:

```bash
/usr/bin/php /home/USER/public_html/php-api/scripts/cron-renew-subscriptions.php
```

9. Smoke tests:

```bash
curl https://api.tudominio.com/api/v1/health
```

- Probar login admin en `https://admin.tudominio.com`.
- Probar dashboard y CRUD.
- Opcional: ejecutar `php-api/scripts/smoke.sh` (requiere `jq`).

## Notas para MAUI

Consumir con:

- `Authorization: Bearer <token>`
- `Accept-Language: es` o `en`
- Respuestas de listas con formato paginado:

```json
{
  "success": true,
  "message": "...",
  "data": {
    "items": [],
    "page": 1,
    "pageSize": 20,
    "total": 0
  }
}
```
