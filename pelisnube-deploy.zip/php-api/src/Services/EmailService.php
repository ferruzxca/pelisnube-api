<?php

declare(strict_types=1);

namespace App\Services;

use App\Core\Env;

final class EmailService
{
    public function sendOtp(string $email, string $code, string $lang): bool
    {
        $subject = $lang === 'en' ? 'PelisNube password recovery code' : 'Codigo de recuperacion PelisNube';
        $body = $lang === 'en'
            ? "Your one-time code is: {$code}. It expires in a few minutes."
            : "Tu codigo temporal es: {$code}. Expira en unos minutos.";

        $fromEmail = (string) Env::get('SMTP_FROM_EMAIL', 'no-reply@example.com');
        $fromName = (string) Env::get('SMTP_FROM_NAME', 'PelisNube');

        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $fromName . ' <' . $fromEmail . '>',
        ];

        $sent = @mail($email, $subject, $body, implode("\r\n", $headers));

        if (!$sent) {
            $logLine = sprintf(
                "[%s] OTP mail fallback failed for %s. Code: %s\n",
                date('Y-m-d H:i:s'),
                $email,
                $code
            );
            $logPath = dirname(__DIR__, 2) . '/storage/logs/mail.log';
            @file_put_contents($logPath, $logLine, FILE_APPEND);
        }

        return $sent;
    }
}
