SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE rate_limits;
TRUNCATE TABLE subscription_history;
TRUNCATE TABLE plan_history;
TRUNCATE TABLE section_history;
TRUNCATE TABLE content_history;
TRUNCATE TABLE user_history;
TRUNCATE TABLE audit_logs;
TRUNCATE TABLE password_otps;
TRUNCATE TABLE payment_attempts;
TRUNCATE TABLE favorites;
TRUNCATE TABLE content_sections;
TRUNCATE TABLE subscriptions;
TRUNCATE TABLE subscription_plans;
TRUNCATE TABLE sections;
TRUNCATE TABLE contents;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO users (id, name, email, password_hash, role, status, is_active, preferred_lang, must_change_password, created_at, updated_at)
VALUES
('00000000-0000-0000-0000-000000000001', 'Super Admin', 'superadmin@pelisnube.local', '$2y$12$9dt7eri.zlRhH4jd0DhgWeRG/eAptqLM8/Yhhwhu76DW5g49wuHb.', 'SUPER_ADMIN', 'ACTIVE', 1, 'es', 1, NOW(), NOW()),
('00000000-0000-0000-0000-000000000002', 'Admin Operativo', 'admin@pelisnube.local', '$2y$12$9dt7eri.zlRhH4jd0DhgWeRG/eAptqLM8/Yhhwhu76DW5g49wuHb.', 'ADMIN', 'ACTIVE', 1, 'es', 0, NOW(), NOW()),
('00000000-0000-0000-0000-000000000003', 'Usuario Demo', 'user@pelisnube.local', '$2y$12$VkRc1wPdiy1pnL8LMkeBTOPeoG5iE5oCqj7s9.iz5L6T3XwR8a.Ke', 'USER', 'ACTIVE', 1, 'es', 0, NOW(), NOW());

INSERT INTO subscription_plans (id, code, name, price_monthly, currency, quality, screens, is_active, created_at, updated_at)
VALUES
('20000000-0000-0000-0000-000000000001', 'BASIC', 'Basic', 119.00, 'MXN', 'HD', 1, 1, NOW(), NOW()),
('20000000-0000-0000-0000-000000000002', 'STANDARD', 'Standard', 189.00, 'MXN', 'Full HD', 2, 1, NOW(), NOW()),
('20000000-0000-0000-0000-000000000003', 'PREMIUM', 'Premium', 259.00, 'MXN', '4K + HDR', 4, 1, NOW(), NOW());

INSERT INTO subscriptions (id, user_id, plan_id, status, started_at, renewal_at, ended_at, is_active, created_at, updated_at)
VALUES
('30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000003', '20000000-0000-0000-0000-000000000002', 'ACTIVE', NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), NULL, 1, NOW(), NOW());

INSERT INTO sections (id, section_key, name, description, sort_order, is_home_visible, is_active, created_at, updated_at)
VALUES
('10000000-0000-0000-0000-000000000001', 'trending-now', 'Tendencias ahora', 'Lo mas visto esta semana.', 1, 1, 1, NOW(), NOW()),
('10000000-0000-0000-0000-000000000002', 'estrenos', 'Estrenos', 'Nuevos lanzamientos para maratonear.', 2, 1, 1, NOW(), NOW()),
('10000000-0000-0000-0000-000000000003', 'series-estrella', 'Series estrella', 'Series destacadas por la comunidad.', 3, 1, 1, NOW(), NOW()),
('10000000-0000-0000-0000-000000000004', 'sci-fi-night', 'Sci-Fi Night', 'Ciencia ficcion para ver de noche.', 4, 1, 1, NOW(), NOW()),
('10000000-0000-0000-0000-000000000005', 'drama-selecto', 'Drama selecto', 'Historias intensas y memorables.', 5, 1, 1, NOW(), NOW()),
('10000000-0000-0000-0000-000000000006', 'accion-max', 'Accion Max', 'Accion y adrenalina sin pausa.', 6, 1, 1, NOW(), NOW());

INSERT INTO payment_attempts (id, user_id, user_email, plan_id, amount, currency, card_last4, card_brand, status, reason, metadata, created_at)
VALUES
('40000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000003', 'user@pelisnube.local', '20000000-0000-0000-0000-000000000002', 189.00, 'MXN', '4242', 'SIMULATED', 'SUCCESS', NULL, '{"seed":true}', NOW());

INSERT INTO contents (id, title, slug, type, synopsis, year, duration, rating, trailer_watch_url, trailer_embed_url, poster_url, banner_url, is_active, created_at, updated_at) VALUES
('50000000-0000-0000-0000-000000000001','Nebula Shift','nebula-shift','MOVIE','Historia 1 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,96,7.1,'https://www.youtube.com/watch?v=5PSNL1qE6VY','https://www.youtube.com/embed/5PSNL1qE6VY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=1','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=1',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000002','Codigo Aurora','codigo-aurora','SERIES','Historia 2 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,44,7.2,'https://www.youtube.com/watch?v=zSWdZVtXT7E','https://www.youtube.com/embed/zSWdZVtXT7E','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=2','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=2',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000003','Noche en Kyoto','noche-en-kyoto','MOVIE','Historia 3 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,98,7.3,'https://www.youtube.com/watch?v=6ZfuNTqbHE8','https://www.youtube.com/embed/6ZfuNTqbHE8','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=3','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=3',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000004','Valle Sombra','valle-sombra','SERIES','Historia 4 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,46,7.4,'https://www.youtube.com/watch?v=b9EkMc79ZSU','https://www.youtube.com/embed/b9EkMc79ZSU','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=4','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=4',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000005','Radar 404','radar-404','MOVIE','Historia 5 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,100,7.5,'https://www.youtube.com/watch?v=TcMBFSGVi1c','https://www.youtube.com/embed/TcMBFSGVi1c','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=5','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=5',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000006','Linea de Fuego','linea-de-fuego','SERIES','Historia 6 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,48,7.6,'https://www.youtube.com/watch?v=QdBZY2fkU-0','https://www.youtube.com/embed/QdBZY2fkU-0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=6','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=6',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000007','Ultimo Replay','ultimo-replay','MOVIE','Historia 7 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,102,7.7,'https://www.youtube.com/watch?v=5MgBikgcWnY','https://www.youtube.com/embed/5MgBikgcWnY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=7','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=7',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000008','Archivo Violeta','archivo-violeta','SERIES','Historia 8 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,50,7.8,'https://www.youtube.com/watch?v=YR5x2Z6I1X0','https://www.youtube.com/embed/YR5x2Z6I1X0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=8','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=8',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000009','Orbita Cero','orbita-cero','MOVIE','Historia 9 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,104,7.9,'https://www.youtube.com/watch?v=JfVOs4VSpmA','https://www.youtube.com/embed/JfVOs4VSpmA','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=9','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=9',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000010','Puente 9','puente-9','SERIES','Historia 10 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,52,8.0,'https://www.youtube.com/watch?v=8Qn_spdM5Zg','https://www.youtube.com/embed/8Qn_spdM5Zg','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=10','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=10',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000011','Marea Roja','marea-roja','MOVIE','Historia 11 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,106,8.1,'https://www.youtube.com/watch?v=5PSNL1qE6VY','https://www.youtube.com/embed/5PSNL1qE6VY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=11','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=11',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000012','Vector Norte','vector-norte','SERIES','Historia 12 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,54,8.2,'https://www.youtube.com/watch?v=zSWdZVtXT7E','https://www.youtube.com/embed/zSWdZVtXT7E','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=12','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=12',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000013','Ciudad Prisma','ciudad-prisma','MOVIE','Historia 13 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,108,8.3,'https://www.youtube.com/watch?v=6ZfuNTqbHE8','https://www.youtube.com/embed/6ZfuNTqbHE8','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=13','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=13',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000014','Luz de Titan','luz-de-titan','SERIES','Historia 14 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,56,8.4,'https://www.youtube.com/watch?v=b9EkMc79ZSU','https://www.youtube.com/embed/b9EkMc79ZSU','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=14','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=14',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000015','Punto Ciego','punto-ciego','MOVIE','Historia 15 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,110,8.5,'https://www.youtube.com/watch?v=TcMBFSGVi1c','https://www.youtube.com/embed/TcMBFSGVi1c','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=15','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=15',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000016','Rastro Digital','rastro-digital','SERIES','Historia 16 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,43,8.6,'https://www.youtube.com/watch?v=QdBZY2fkU-0','https://www.youtube.com/embed/QdBZY2fkU-0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=16','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=16',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000017','Costa Fria','costa-fria','MOVIE','Historia 17 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,112,8.7,'https://www.youtube.com/watch?v=5MgBikgcWnY','https://www.youtube.com/embed/5MgBikgcWnY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=17','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=17',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000018','Eje Terminal','eje-terminal','SERIES','Historia 18 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,45,8.8,'https://www.youtube.com/watch?v=YR5x2Z6I1X0','https://www.youtube.com/embed/YR5x2Z6I1X0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=18','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=18',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000019','Mision Eclipse','mision-eclipse','MOVIE','Historia 19 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,114,8.9,'https://www.youtube.com/watch?v=JfVOs4VSpmA','https://www.youtube.com/embed/JfVOs4VSpmA','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=19','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=19',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000020','Protocolo Niebla','protocolo-niebla','SERIES','Historia 20 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,47,9.0,'https://www.youtube.com/watch?v=8Qn_spdM5Zg','https://www.youtube.com/embed/8Qn_spdM5Zg','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=20','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=20',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000021','Camino de Acero','camino-de-acero','MOVIE','Historia 21 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,116,9.1,'https://www.youtube.com/watch?v=5PSNL1qE6VY','https://www.youtube.com/embed/5PSNL1qE6VY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=21','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=21',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000022','Anillo Solar','anillo-solar','SERIES','Historia 22 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,49,9.2,'https://www.youtube.com/watch?v=zSWdZVtXT7E','https://www.youtube.com/embed/zSWdZVtXT7E','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=22','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=22',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000023','Clave Meridian','clave-meridian','MOVIE','Historia 23 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,118,9.3,'https://www.youtube.com/watch?v=6ZfuNTqbHE8','https://www.youtube.com/embed/6ZfuNTqbHE8','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=23','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=23',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000024','Eco del Trueno','eco-del-trueno','SERIES','Historia 24 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,51,9.4,'https://www.youtube.com/watch?v=b9EkMc79ZSU','https://www.youtube.com/embed/b9EkMc79ZSU','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=24','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=24',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000025','Horizonte Delta','horizonte-delta','MOVIE','Historia 25 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,120,9.5,'https://www.youtube.com/watch?v=TcMBFSGVi1c','https://www.youtube.com/embed/TcMBFSGVi1c','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=25','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=25',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000026','Ruta Quimera','ruta-quimera','SERIES','Historia 26 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,53,7.0,'https://www.youtube.com/watch?v=QdBZY2fkU-0','https://www.youtube.com/embed/QdBZY2fkU-0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=26','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=26',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000027','Nexo Urbano','nexo-urbano','MOVIE','Historia 27 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,122,7.1,'https://www.youtube.com/watch?v=5MgBikgcWnY','https://www.youtube.com/embed/5MgBikgcWnY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=27','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=27',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000028','Frontera Polar','frontera-polar','SERIES','Historia 28 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,55,7.2,'https://www.youtube.com/watch?v=YR5x2Z6I1X0','https://www.youtube.com/embed/YR5x2Z6I1X0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=28','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=28',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000029','Bitacora Humo','bitacora-humo','MOVIE','Historia 29 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,124,7.3,'https://www.youtube.com/watch?v=JfVOs4VSpmA','https://www.youtube.com/embed/JfVOs4VSpmA','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=29','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=29',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000030','Ritmo Salvaje','ritmo-salvaje','SERIES','Historia 30 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,42,7.4,'https://www.youtube.com/watch?v=8Qn_spdM5Zg','https://www.youtube.com/embed/8Qn_spdM5Zg','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=30','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=30',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000031','Nivel Fantasma','nivel-fantasma','MOVIE','Historia 31 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,126,7.5,'https://www.youtube.com/watch?v=5PSNL1qE6VY','https://www.youtube.com/embed/5PSNL1qE6VY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=31','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=31',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000032','Duna Vertical','duna-vertical','SERIES','Historia 32 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,44,7.6,'https://www.youtube.com/watch?v=zSWdZVtXT7E','https://www.youtube.com/embed/zSWdZVtXT7E','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=32','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=32',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000033','Arco Voltaico','arco-voltaico','MOVIE','Historia 33 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,128,7.7,'https://www.youtube.com/watch?v=6ZfuNTqbHE8','https://www.youtube.com/embed/6ZfuNTqbHE8','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=33','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=33',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000034','Matriz de Cristal','matriz-de-cristal','SERIES','Historia 34 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,46,7.8,'https://www.youtube.com/watch?v=b9EkMc79ZSU','https://www.youtube.com/embed/b9EkMc79ZSU','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=34','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=34',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000035','Cuarto Umbral','cuarto-umbral','MOVIE','Historia 35 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,95,7.9,'https://www.youtube.com/watch?v=TcMBFSGVi1c','https://www.youtube.com/embed/TcMBFSGVi1c','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=35','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=35',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000036','Laberinto Azul','laberinto-azul','SERIES','Historia 36 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,48,8.0,'https://www.youtube.com/watch?v=QdBZY2fkU-0','https://www.youtube.com/embed/QdBZY2fkU-0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=36','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=36',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000037','Motor Vanta','motor-vanta','MOVIE','Historia 37 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,97,8.1,'https://www.youtube.com/watch?v=5MgBikgcWnY','https://www.youtube.com/embed/5MgBikgcWnY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=37','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=37',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000038','Codigo Escarlata','codigo-escarlata','SERIES','Historia 38 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,50,8.2,'https://www.youtube.com/watch?v=YR5x2Z6I1X0','https://www.youtube.com/embed/YR5x2Z6I1X0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=38','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=38',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000039','Termino Final','termino-final','MOVIE','Historia 39 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,99,8.3,'https://www.youtube.com/watch?v=JfVOs4VSpmA','https://www.youtube.com/embed/JfVOs4VSpmA','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=39','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=39',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000040','Sector Aurora','sector-aurora','SERIES','Historia 40 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,52,8.4,'https://www.youtube.com/watch?v=8Qn_spdM5Zg','https://www.youtube.com/embed/8Qn_spdM5Zg','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=40','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=40',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000041','Plano Inverso','plano-inverso','MOVIE','Historia 41 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,101,8.5,'https://www.youtube.com/watch?v=5PSNL1qE6VY','https://www.youtube.com/embed/5PSNL1qE6VY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=41','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=41',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000042','Atlas Marino','atlas-marino','SERIES','Historia 42 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,54,8.6,'https://www.youtube.com/watch?v=zSWdZVtXT7E','https://www.youtube.com/embed/zSWdZVtXT7E','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=42','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=42',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000043','Estacion Xenon','estacion-xenon','MOVIE','Historia 43 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,103,8.7,'https://www.youtube.com/watch?v=6ZfuNTqbHE8','https://www.youtube.com/embed/6ZfuNTqbHE8','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=43','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=43',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000044','Portal Cobalto','portal-cobalto','SERIES','Historia 44 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2022,56,8.8,'https://www.youtube.com/watch?v=b9EkMc79ZSU','https://www.youtube.com/embed/b9EkMc79ZSU','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=44','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=44',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000045','Ruta de Ceniza','ruta-de-ceniza','MOVIE','Historia 45 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2023,105,8.9,'https://www.youtube.com/watch?v=TcMBFSGVi1c','https://www.youtube.com/embed/TcMBFSGVi1c','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=45','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=45',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000046','Blindaje Lunar','blindaje-lunar','SERIES','Historia 46 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2024,43,9.0,'https://www.youtube.com/watch?v=QdBZY2fkU-0','https://www.youtube.com/embed/QdBZY2fkU-0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=46','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=46',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000047','Nucleo Prisma','nucleo-prisma','MOVIE','Historia 47 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2025,107,9.1,'https://www.youtube.com/watch?v=5MgBikgcWnY','https://www.youtube.com/embed/5MgBikgcWnY','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=47','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=47',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000048','Isla Vector','isla-vector','SERIES','Historia 48 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2026,45,9.2,'https://www.youtube.com/watch?v=YR5x2Z6I1X0','https://www.youtube.com/embed/YR5x2Z6I1X0','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=48','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=48',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000049','Vigilancia 27','vigilancia-27','MOVIE','Historia 49 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2020,109,9.3,'https://www.youtube.com/watch?v=JfVOs4VSpmA','https://www.youtube.com/embed/JfVOs4VSpmA','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=49','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=49',1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000050','Escena Terminal','escena-terminal','SERIES','Historia 50 de drama, accion y tecnologia con decisiones criticas para sus protagonistas.',2021,47,9.4,'https://www.youtube.com/watch?v=8Qn_spdM5Zg','https://www.youtube.com/embed/8Qn_spdM5Zg','https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80&sig=50','https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?auto=format&fit=crop&w=1600&q=80&sig=50',1,NOW(),NOW())
;
INSERT INTO content_sections (content_id, section_id, sort_order, is_active, created_at, updated_at) VALUES
('50000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000002','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000003','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000003','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000004','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000004','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000005','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000005','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000006','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000006','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000007','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000007','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000008','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000008','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000009','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000009','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000010','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000010','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000011','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000011','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000012','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000012','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000013','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000013','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000014','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000014','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000015','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000015','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000016','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000016','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000017','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000017','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000018','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000018','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000019','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000019','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000020','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000020','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000021','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000021','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000022','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000022','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000023','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000023','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000024','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000024','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000025','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000025','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000026','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000026','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000027','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000027','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000028','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000028','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000029','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000029','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000030','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000030','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000031','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000031','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000032','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000032','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000033','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000033','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000034','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000034','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000035','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000035','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000036','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000036','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000037','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000037','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000038','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000038','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000039','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000039','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000040','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000040','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000041','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000041','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000042','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000042','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000043','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000043','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000044','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000044','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000045','10000000-0000-0000-0000-000000000004',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000045','10000000-0000-0000-0000-000000000006',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000046','10000000-0000-0000-0000-000000000005',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000046','10000000-0000-0000-0000-000000000001',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000047','10000000-0000-0000-0000-000000000006',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000047','10000000-0000-0000-0000-000000000002',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000048','10000000-0000-0000-0000-000000000001',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000048','10000000-0000-0000-0000-000000000003',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000049','10000000-0000-0000-0000-000000000002',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000049','10000000-0000-0000-0000-000000000004',1,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000050','10000000-0000-0000-0000-000000000003',0,1,NOW(),NOW()),
('50000000-0000-0000-0000-000000000050','10000000-0000-0000-0000-000000000005',1,1,NOW(),NOW())
;
